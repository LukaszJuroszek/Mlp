﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Gen
{
    public class Population
    {
        private static Random rand;
        public List<IndividualPerson> CurrentPopulation { get; private set; }
        public int[] Template { get; private set; }
        public Population(int lenth,int[] template)
        {
            rand = new Random();
            CurrentPopulation = new List<IndividualPerson>();
            var population = new List<IndividualPerson>();
            Template = template;
            for (var i = 0;i < lenth;i++)
            {
                population.Add(new IndividualPerson(template.Length,Template));
                Console.WriteLine(population[i].ToString());
            }
            CurrentPopulation = population;
            CoutPopulationMarks();
        }
        private void CoutPopulationMarks()
        {
            CurrentPopulation.ForEach(x => x.CountMarks(Template));
        }
        private int GetAllMarks()
        {
            return CurrentPopulation.Sum(x => x.Mark);
        }
        public int GetRandomParentIndex()
        {
            var randomNumberFromPopulation = rand.Next(0,GetAllMarks());
            Console.WriteLine(randomNumberFromPopulation);
            var currentSum = 0;
            for (var i = 0;i < CurrentPopulation.Count;i++)
            {
                currentSum += CurrentPopulation[i].Mark;
                if (currentSum >= randomNumberFromPopulation)
                    return i;
            }
            return CurrentPopulation.Count;
        }
    }
}
