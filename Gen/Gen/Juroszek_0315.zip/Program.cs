﻿using System;

namespace Gen
{
    class Program
    {
        static void Main(string[] args)
        {
            var popLenth = 50;
            var pop = new Population(popLenth,new int[] { 1,1,1,1,0,0,0 });
            Console.WriteLine(pop.GetRandomParentIndex());
        }
    }
}
